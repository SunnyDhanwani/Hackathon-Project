import React, {  useState } from 'react'
import { Navbar } from './Navbar'
import axios from 'axios';


export default function TrackProduct() {
    const [trackingId,setTrackingId] = useState("")
    const [product,setProduct] = useState([])


    const handleInput = (text) =>{
        setTrackingId(text)
    }
    const handleSearch = () =>{
        axios.get("http://localhost:2345/product/"+trackingId) 
        .then((res)=>{
            // setProducts(res.data)
            setProduct(res.data.data)
        })
    }

    const otpVerify = () => {
        // axios.get("http://localhost:2345/product/testroute").then((res)=>{var ppp = res.data.data});
        axios.post("http://localhost:2345/product/testroute",{})
    }

    const handleLogin = () =>{
        otpVerify();
    }
    return (
        <>
        <Navbar/>
        <div>
            <input type="text" value ={trackingId} placeholder ="Enter tracking Id" onChange={(e)=>handleInput(e.target.value)}/>
            <button onClick={handleSearch}>Search</button>
        </div>

        <div style={{textAlign:"center"}}>
                {product.warehouseStatus
                    ? <> `Your product is at warehouse and will be delivered by ${product.deliveryDate}`
                        <button onClick = {handleLogin}>change date and time</button>
                    </>
                    : "Out for delivery"}
            <br />
            {/* {product.warehouseStatus === false ? 
            <button onClick = {handleLogin}>change date and time</button>
            :
            null} */}
            </div>
        </>
    )
}
